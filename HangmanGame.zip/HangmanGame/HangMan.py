#---Initializations---#

import turtle as trtl
import random as rand

word_file = "wordlist.txt"
word_file2 = "movies.txt"
word_file3 = "videogames.txt"
word_file4 = "tech.txt"

wn = trtl.Screen()
wn.setup(width=1.0, height=1.0)


#---Turtle_Setup---#

post_person_drawer = trtl.Turtle()
post_person_drawer.pensize(5)
post_person_drawer.speed("fast")

word_drawer = trtl.Turtle()
word_drawer.pensize(5)
word_drawer.speed("fast")

info_writer = trtl.Turtle()
info_writer.speed("fast")

lives_tracker = trtl.Turtle()
lives_tracker.speed("fast")


#---Lists---#

possible_words = []

letters_guessed = []


#---Variables---#

lives = 6

letter_count = 0

checking_letters = False

was_there_a_letter = False

input_l = None

correct_letter_amount = 0



#---Main_Menu---#

def main_menu_setup():
    info_writer.clear()
    info_writer.penup()
    info_writer.goto(-150, 300)
    info_writer.pendown()
    info_writer.write("HANGMAN", font=("Arial", 64, "bold"))
    info_writer.penup()
    info_writer.goto(-100, 100) 
    info_writer.pendown()
    info_writer.write("Click S to start", font=("Arial", 32, "bold"))
    info_writer.penup()
    check_for_start_letter()

def check_for_start_letter():
    global input_l
    for letter in "abcdefghijklmnopqrstuvwxyz":
        wn.onkeypress(lambda l=letter: on_key_start(l), letter)
        wn.listen()
        wn.update()
    while input_l is None:
        wn.update()
    else:
        if input_l == "s":
            start_game(0, 0)
        else:
            input_l = None
            check_for_start_letter()

def start_game(x, y):
    info_writer.clear()
    set_up_difficulty_page()


#---Difficulty_Selector---#

def set_up_difficulty_page():
    print("Difficulty Selector")
    info_writer.clear()
    info_writer.penup()
    info_writer.penup()
    info_writer.goto(-550, 200)
    info_writer.pendown()
    info_writer.write("Select a difficulty: 1 for easy, 2 for classic", font=("Arial", 32, "normal"))
    info_writer.penup()
    info_writer.goto(-550, 150)
    info_writer.pendown()
    info_writer.write("If you choose another option other than classic,", font=("Arial", 32, "normal"))
    info_writer.penup()
    info_writer.goto(-550, 100)
    info_writer.pendown()
    info_writer.write("your number of lifes change but the hangman wont match up", font=("Arial", 32, "normal"))
    difficulty_selector()

def difficulty_selector(): 
    global input_l
    global lives
    for letter in "123":
        wn.onkeypress(lambda l=letter: on_key_start(l), letter)
        wn.listen()
        wn.update()
    while input_l is None:
        wn.update()
    else:
        if input_l == "1":
            lives = 10
            info_writer.clear()
            word_file_selector_start()
        elif input_l == "2":
            lives = 6
            info_writer.clear()
            word_file_selector_start()
        else:
            input_l = None
            difficulty_selector()


#---word file selector---#

def word_file_selector_start():
    info_writer.clear()
    info_writer.penup()
    info_writer.goto(-350, 200)
    info_writer.pendown()
    info_writer.write("Select a word file: 1 for basic, 2 for movies, 3 for video games, 4 for tech", font=("Arial", 32, "normal"))
    word_file_selector()

def word_file_selector():
    global input_l
    input_l = None
    global word_file_selected
    for letter in "1234":
        wn.onkeypress(lambda l=letter: on_key_start(l), letter)
        wn.listen()
        wn.update()
    while input_l is None:
        wn.update()
    else:
        if input_l == "1":
            word_file_selected = word_file
            getfile()
            draw_post()
            draw_lines()
            write_info()
            input_checker()
        elif input_l == "2":
            word_file_selected = word_file2
            getfile()
            draw_post()
            draw_lines()
            write_info()
            input_checker()
        elif input_l == "3":
            word_file_selected = word_file3
            getfile()
            draw_post()
            draw_lines()
            write_info()
            input_checker()
        elif input_l == "4":
            word_file_selected = word_file4
            getfile()
            draw_post()
            draw_lines()
            write_info()
            input_checker()
        else:
            input_l = None
            word_file_selector()


#---Setup_Functions---#


def getfile():     #Made with the help of github co-pilot
    global word
    global possible_words
    global word_file_selected
    with open(word_file_selected, 'r') as file:
        words = file.readlines()
        possible_words = [words.strip() for words in words]
        word = rand.choice(possible_words)
        
def draw_post():
    info_writer.clear()
    post_person_drawer.pendown()
    post_person_drawer.forward(50)
    post_person_drawer.back(25)
    post_person_drawer.left(90)
    post_person_drawer.forward(150)
    post_person_drawer.left(90)
    post_person_drawer.forward(50)
    post_person_drawer.left(90)
    post_person_drawer.forward(25)

def draw_lines():
    global letter_count
    word_drawer.penup()
    word_drawer.goto(-350, -200)
    print(word)
    for letter in word:
        word_drawer.forward(50)
        word_drawer.penup()
        word_drawer.forward(25)
        word_drawer.pendown()
        letter_count += 1
    word_drawer.forward(50)
    word_drawer.penup()
    word_drawer.forward(25)
    word_drawer.pendown()
        
def write_info():
    info_writer.penup()
    info_writer.goto(-350, 350)
    info_writer.pendown()
    info_writer.write("Created by: Dakota Higdon, Sophmore, Nevada High School, Nevada, IA", font=("Arial", 10, "normal"))
    info_writer.penup()
    info_writer.goto(-350, 270)
    info_writer.write("Welcome to Hangman!", font=("Arial", 32, "normal"))
    info_writer.penup()
    info_writer.goto(-350, 240)
    info_writer.write("Guess a letter: ", font=("Arial", 32, "normal"))
    info_writer.penup()
    info_writer.goto(-350, 200)
    info_writer.penup()
    lives_tracker.penup()
    lives_tracker.goto(350, 400)
    lives_tracker.pendown()
    lives_tracker.write("Lives: ", font=("Arial", 32, "normal"))
    lives_tracker.penup()
    lives_tracker.goto(350, 350) 
    lives_tracker.pendown()
    lives_tracker.write(str(lives), font=("Arial", 32, "normal"))
    lives_tracker.penup()
    lives_tracker.goto(-350, 200)


#---Track_Lives---#

def update_lives():
    lives_tracker.clear()
    lives_tracker.penup()
    lives_tracker.goto(350, 400)
    lives_tracker.pendown()
    lives_tracker.write("Lives: ", font=("Arial", 32, "normal"))
    lives_tracker.penup()
    lives_tracker.goto(350, 350) 
    lives_tracker.pendown()
    lives_tracker.write(str(lives), font=("Arial", 32, "normal"))
    lives_tracker.penup()

#---Input_Functions---#

def check_letter_correctness():
    global input_l
    global checking_letters
    global lives
    while lives > 0:
        word_drawer.penup()
        while input_l is None:
            wn.update()
        else:
            if input_l in letters_guessed:
                input_l = None
            else:
                letters_guessed.append(input_l)
                checking_letters = True
            word_drawer.goto(-350, -200)
            go_through_letters()

def go_through_letters():
    global checking_letters
    global was_there_a_letter
    global correct_letter_amount
    global input_l
    while checking_letters == True:
        for letter in word:
            word_drawer.penup()
            word_drawer.forward(75)
            if letter == input_l:
                print("correct")
                correct_letter_amount += 1   
                letter_correct()
        if was_there_a_letter == False:
            letter_incorrect()
        if lives == 0:
            end_game()
        if correct_letter_amount == letter_count:
            won_game()
        was_there_a_letter = False
        checking_letters = False
        input_l = None

def end_game():
    if lives == 0:
        print("You Lose")
        info_writer.clear()
        word_drawer.clear()
        post_person_drawer.clear()
        info_writer.penup()
        info_writer.goto(-50,0)
        info_writer.pendown()
        info_writer.write("You Lose", font=("Arial", 32, "normal"))
        info_writer.penup()
        info_writer.goto(-50, -50)
        info_writer.pendown()
        info_writer.write("The word was: ", font=("Arial", 32, "normal"))
        info_writer.penup()
        info_writer.goto(50, -100)
        info_writer.pendown()
        info_writer.write(word, font=("Arial", 32, "normal"))
        info_writer.hideturtle()
        word_drawer.hideturtle()
        post_person_drawer.hideturtle() 
        
def letter_incorrect():
    global lives
    global input_l
    global checking_letters
    print("Incorrect")
    lives -= 1
    update_lives()
    print("Lives: ", lives)
    if input_l != None:
        info_writer.pencolor("red")
        info_writer.write(input_l, font=("Arial", 32, "normal"))
        info_writer.penup()
        info_writer.forward(50)
        info_writer.pendown()
        checking_letters = False
        input_l = None
        make_the_hangman()    

def letter_correct():
    global was_there_a_letter
    global input_l
    global checking_letters
    word_drawer.write(input_l, font=("Arial", 32, "normal"))
    info_writer.penup()
    info_writer.pencolor("green")
    info_writer.write(input_l, font=("Arial", 32, "normal"))
    info_writer.penup()
    info_writer.forward(50)
    info_writer.pendown()
    was_there_a_letter = True
    print("correct:" + input_l) 

def on_key_press(letter):
    global input_l
    input_l = letter
    check_letter_correctness()

def on_key_start(letter):
    global input_l
    input_l = letter

def input_checker():
    for letter in "abcdefghijklmnopqrstuvwxyz":
        wn.onkeypress(lambda l=letter: on_key_press(l), letter)
        wn.listen()
        wn.update()

def make_the_hangman():
    if lives == 5:
        post_person_drawer.right(90)
        post_person_drawer.circle(10)
    elif lives == 4:
        post_person_drawer.left(90)
        post_person_drawer.penup()
        post_person_drawer.forward(20)
        post_person_drawer.pendown()
        post_person_drawer.forward(40)
    elif lives == 3:
        post_person_drawer.right(180)
        post_person_drawer.forward(15)
        post_person_drawer.right(45)
        post_person_drawer.forward(20)
        post_person_drawer.back(20)
    elif lives == 2:
        post_person_drawer.left(90)
        post_person_drawer.forward(20)
        post_person_drawer.back(20)
    elif lives == 1:
        post_person_drawer.left(135)
        post_person_drawer.forward(20)
        post_person_drawer.left(45)
        post_person_drawer.forward(20)
        post_person_drawer.back(20)
    elif lives == 0:
        post_person_drawer.right(90)
        post_person_drawer.forward(20)
        post_person_drawer.back(20)


def won_game():
    if lives > 0:
        print("You Win")
        info_writer.clear()
        word_drawer.clear()
        post_person_drawer.clear()
        info_writer.penup()
        info_writer.goto(-50,0)
        info_writer.pendown()
        info_writer.write("You Win", font=("Arial", 64, "bold"))        
        info_writer.penup()
        info_writer.goto(-50, -100)
        info_writer.pendown()
        info_writer.write("The word was: ", font=("Arial", 32, "normal"))
        info_writer.penup()
        info_writer.goto(-50, -150)
        info_writer.pendown()
        info_writer.write(word, font=("Arial", 32, "normal"))
        info_writer.hideturtle()
        word_drawer.hideturtle()
        post_person_drawer.hideturtle() 
    
#--Function_Calls--#

main_menu_setup()

#---Ending---#

wn.listen()
wn.mainloop()

#---End_Of_File---#